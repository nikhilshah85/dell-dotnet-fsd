﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mymvcapp.Models
{
    public class Products
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public double pPrice { get; set; }
        public string pCategory { get; set; }
        public int pAvailableQty { get; set; }


        static List<Products> productList = null;

        public Products()
        {
            if (productList == null)
            {
                productList = new List<Products>();

                productList.Add(new Products() { pId = 101, pName = "IPhone", pAvailableQty = 20, pCategory = "Smart Phone", pPrice = 95000 });
                productList.Add(new Products() { pId = 102, pName = "Fossil QFounder", pAvailableQty = 10, pCategory = "Smart Watch", pPrice = 45000 });
                productList.Add(new Products() { pId = 103, pName = "IPad", pAvailableQty = 5, pCategory = "Tablet", pPrice = 49000 });
                productList.Add(new Products() { pId = 104, pName = "Selfie Stick", pAvailableQty = 1, pCategory = "Photo Stick", pPrice = 500 });
                productList.Add(new Products() { pId = 105, pName = "Super Dry", pAvailableQty = 200, pCategory = "T=Shirt", pPrice = 1900 });
              }
              }
            
        

        public List<Products> GetProducts()
        {
            return productList;
        }

    }
}
