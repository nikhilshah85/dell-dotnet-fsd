﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mymvcapp.Models;
namespace mymvcapp.Controllers
{
    public class ShoppingController : Controller
    {

        Products productObj = new Products();
        public IActionResult DisplayProducts()
        {
            return View(productObj.GetProducts());
        }


        public IActionResult ProductList()
        {
            //view data good got inbuild data type, old object
            int totalProduct = 10; //this may come from model etc
            ViewData["totalProducts"] = totalProduct;
            ViewData["developerName"] = "Nikhil";
            ViewData["cost"] = 25000;

            //viewbag, light weight
            //
            //it is very bad that we hard the data, and that to in a controller
            //we should be doing the data related things in model file, controller will take data from model and pass it to the view
            List<string> products = new List<string>();
            products.Add("Pepsi");
            products.Add("Maggie");
            products.Add("Frosstick");
            products.Add("Sandwitch");
            products.Add("Pasta");
            products.Add("Pizza");

            ViewBag.products = products;
            return View();

        }
    }
}
