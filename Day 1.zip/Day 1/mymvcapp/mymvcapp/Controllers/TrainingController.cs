﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mymvcapp.Controllers
{
    public class TrainingController : Controller
    {

        public IActionResult Abouttraining()
        {
            return View();
        }

        public IActionResult ParticapantList()
        {
            //we can generate some data here and pass it to the view
            return View();
        }
        public IActionResult TrainingDetails()
        {
            return View();
        }    
    
    }
}
